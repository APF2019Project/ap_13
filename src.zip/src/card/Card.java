package card;

import java.util.ArrayList;

public class Card {
    ArrayList<Card> cards;
    int cardID;
    
}
