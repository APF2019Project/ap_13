package view;

import logic.Account;

public class Game {
    Account account;
    Menu menu;
    Battle battle;
}
