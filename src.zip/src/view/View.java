package view;

public class View {
    void select(String name){}
    void showHand(){}
    void plant(String name , int x , int y){}
    void remove(int x , int y){}
    void endTurn(){}
    void showLawn(){}
    void list(){}
    void record(){}
    void showLanes(){}
    void put(String name , int number){}
    void start(){}
    void ready(){}
}
