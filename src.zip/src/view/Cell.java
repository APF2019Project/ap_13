package view;

import java.util.ArrayList;

public class Cell {
    int x;
    int y;
    boolean type;
    ArrayList<Card> cards;
    boolean plantCanBeInserted;
}
