package view;

import java.util.ArrayList;

public class Map {
    ArrayList<Map> maps;
    int HEIGHT;
    int WIDTH;
    Cell[][] board = new Cell [HEIGHT][WIDTH];
    int getDistance(Cell cell1 , Cell cell2){}
    Cell getCell(int x , int y){

    }
    ArrayList<Card> getCardOnCell(Cell cell){}
}
