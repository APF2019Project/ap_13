package menu;

public class Menu {
}
