package logic;

public class Player {
    Account user;
    int sun;
    Hand hand;
    void handleWin(){
    }
}

class AI extends Player {
    void preProcess(){}
    void play(){}
}
